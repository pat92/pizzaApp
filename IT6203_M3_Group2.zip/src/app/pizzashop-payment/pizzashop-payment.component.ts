import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, Validators, FormArray  } from '@angular/forms';
import { PaymentService } from '../services/payment.service';
import { Router } from '@angular/router';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { ItemService } from '../services/item.service';
import { OMService } from '../services/OM.service';

@Component({
  selector: 'app-pizzashop-payment',
  templateUrl: './pizzashop-payment.component.html',
  styleUrls: ['./pizzashop-payment.component.css']
})
export class PizzashopPaymentComponent implements OnInit {
@Input() CardNumber: string = "";
@Input() Month: string = "";
@Input() Year: string = "";
@Input() Cvv: string = "";
@Input() NameOnCard: string = "";
@Input() Street: string = "";
@Input() Zip: string = "";
@Input() City: string = "";
@Input() State: string = "";

  profileForm = this.fb.group({
    CardNumber: ['', Validators.required, Validators.minLength(16),Validators.pattern('[0-9 ]*')],
    Month:['', Validators.required, Validators.maxLength(2),Validators.pattern('[0-9 ]*')],
    Year:['', Validators.required, Validators.max(3),Validators.pattern('[0-9 ]*')],
    Cvv: ['', Validators.required, Validators.max(3),Validators.pattern('[0-9 ]*')],
    NameOnCard:['', Validators.required, Validators.pattern('[a-zA-Z ]*')],
    Street:['', Validators.required, Validators.pattern('[a-zA-Z ]*')],
    Zip: ['', Validators.required,Validators.max(5),Validators.pattern('[0-9 ]*')],
    City:['', Validators.required, Validators.pattern('[a-zA-Z ]*')],
    State:['', Validators.required, Validators.pattern('[a-zA-Z ]*')]
  });

  public mode = 'Add'; //default mode
  private id: any; //payment ID
  private payment:any;
  public orderItems:any[];
  public items: any[] ;
  public grandTotal !: number;
  public orderId: any;

  constructor(private fb: FormBuilder,private _myService: PaymentService, private router:Router, private _itemService: ItemService, private _myOMService: OMService,
  public route: ActivatedRoute) { }
 

ngOnInit() {
this.route.paramMap.subscribe((paramMap: ParamMap ) => {
  if (paramMap.has('_id')){ 
      this.mode = 'Edit'; /*request had a parameter _id */ 
      this.id = paramMap.get('_id');

       //request student info based on the id
       this._myService.getPayment(this.id).subscribe(
        data => { 
            //read data and assign to private variable payment
            this.payment = data;
            //populate the form on the page
            //notice that this is done through the two-way bindings
            // this.profileForm.get('CardNumber')?.setValue(this.payment.CardNumber);
            // this.profileForm.get('Month')?.setValue(this.payment.Month);
            // this.profileForm.get('Year')?.setValue(this.payment.Year);
            // this.profileForm.get('Cvv')?.setValue(this.payment.Cvv);
            // this.profileForm.get('NameOnCard')?.setValue(this.payment.NameOnCard);
            // this.profileForm.get('BillingAddress')?.get('Street')?.setValue(this.payment.Street);
            // this.profileForm.get('BillingAddress')?.get('Zip')?.setValue(this.payment.Zip);
            // this.profileForm.get('BillingAddress')?.get('City')?.setValue(this.payment.City);
            // this.profileForm.get('BillingAddress')?.get('State')?.setValue(this.payment.State);
            this.CardNumber=this.payment.CardNumber;
            this.Month=this.payment.Month;
            this.Year=this.payment.Year;
            this.Cvv=this.payment.Cvv;
            this.NameOnCard=this.payment.NameOnCard;
            this.Street=this.payment.Street;
            this.Zip=this.payment.Zip;
            this.City=this.payment.City;
            this.State=this.payment.State;


        },
        err => console.error(err),
        () => console.log('finished loading')
    );
    }
  else {
    this.mode = 'Add';
    this.id =  null;
    //paramMap.get('cartId');
  }
}); 
this.getItems();
this._myOMService.getProducts()
.subscribe(res=>{
  this.items = res;
  this.grandTotal = this._myOMService.getTotalPrice();
})
}
getItems(){
  this._itemService.getItems()
  .subscribe(
    (res:any)=>{this.orderItems=res[res.length-1].itemData
      //this.orderId = res[res.length-1]._id;
  },
   err => console.error(err),
   () => console.log('finished loading')
   )
   //console.log("Items list  - > ",this.orderItems);
}
  
  getCityByZip(){
    let zip = this.profileForm.get('BillingAddress')?.get('Zip')?.value
    let city:string= "";
    let state:string= "";

    if(zip == "30144" || zip == "30152"){
      city = "Kennesaw";
      state = "GA";
    }else if(zip == "30060" || zip =="30061" || zip == "30062" || zip == "30063" || zip =="30064" || zip=="30065" || zip =="30066" || zip== "30067"||zip=="30068" ||zip=="30069"){
      city = "Marietta";
      state = "GA";
    }else if(zip == "30188"|| zip=="30189"){
      city = "Woodstock"
      state = "GA";
    }else if(zip == "30319" || zip =="30327" || zip == "30328" || zip == "30338" || zip =="30339" || zip=="30342" || zip =="30350" || zip== "30358"||zip=="31150" ||zip=="31156"){
      city = "Sandy Springs";
      state = "GA";
    }else if(zip == "27260" || zip =="27261" || zip == "27262" || zip == "27263" || zip =="27264" || zip=="27265" || zip =="27268"){
      city = "High Point";
      state = "NC";
    }else if(zip == "27284"|| zip=="27285"){
      city = "Kernersville"
      state = "NC";
    }

    
  this.profileForm.get('BillingAddress')?.get('City')?.setValue(city)
  this.profileForm.get('BillingAddress')?.get('State')?.setValue(state)
}

onSubmit() {
  console.log("You submitted: "+ this.profileForm.value);
console.log("order ID from item ->",this.orderId);
  if(this.mode == 'Add'){
    this._myService.addPayment(
      //this.id,
      this.CardNumber,
      this.Month,
      this.Year,
      this.Cvv,
      this.NameOnCard,
      this.Street,
      this.Zip,
      this.City,
      this.State
    );

    this.router.navigate(['/listPayments']);
  }
  
  if (this.mode == 'Edit'){
    this._myService.updatePayment(
      this.id,
      this.CardNumber,
      this.Month,
      this.Year,
      this.Cvv,
      this.NameOnCard,
      this.Street,
      this.Zip,
      this.City,
      this.State
    );

    this.router.navigate(['/listPayments']);
  }
  
}

}


