import { Component, OnInit } from '@angular/core';
import { ItemService } from '../../services/item.service';
import { Router } from '@angular/router';
import { OMService } from 'src/app/services/OM.service';
import {  FormBuilder } from '@angular/forms';
import { ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-list-items',
  templateUrl: './list-items.component.html',
  styleUrls: ['./list-items.component.css']
})
export class ListItemsComponent implements OnInit {

public mode = 'Add'; //default mode

   constructor(private fb: FormBuilder, private _myService: ItemService,private _myOMService: OMService, private router:Router, public route: ActivatedRoute) { }
   
   public items : any = [];
   public orderItems: any =[];
   public grandTotal !: number;
   public id:any;
   //constructor(private cartService : CartService) { }
 
  
   removeItem(item: any){
     this._myOMService.removeCartItem(item);
   }
   emptycart(){
     this._myOMService.removeAllCart();
      }
 
   ngOnInit() {
      //this.id = this._myOMService.getId();
      this._myOMService.getProducts()
     .subscribe(res=>{
       this.items = res;
       this.grandTotal = this._myOMService.getTotalPrice();
     })
     console.log("ItemId - > ", this.id);
     //this.getItems();
      
   }

  //  getItems(){
  //    this._myService.getItems().subscribe(res=>{this.orderItems = res},
  //     err => console.error(err),
  //     () => console.log('finished loading')
  //     )
  //  }
  
   onDelete(itemId: string) {
     this._myOMService.deleteCartItems(itemId);
     this.router.navigate(['/listCartItems']);
 }

 update(){
  this.router.navigate(['/menu']);
 }
 onSubmit(item : any) {
   let cartId =1;
   //console.log("Item : ", item)
   if (this.mode == 'Add')
   //console.log("In list item ", item);
   this._myService.addItems(item);

  this.router.navigate(['/addPayment/'+cartId]);
  }

}
