import { Component, OnInit } from '@angular/core';
import { DeliveryService } from '../../services/delivery.service';
import {Router} from '@angular/router';
import { OMService } from 'src/app/services/OM.service';
import {default as menu} from '../../menu.json';

@Component({
  selector: 'app-list-delivery',
  templateUrl: './list-delivery.component.html',
  styleUrls: ['./list-delivery.component.css']
})
export class ListDeliveryComponent implements OnInit {

  public delivery: any;
  public productList :any;
  public list = menu;
  public filterCategory : any
  public deliveryId:any;

  constructor(private _deliveryService: DeliveryService, private router:Router, private cartService : OMService ) { }

  ngOnInit(): void {
    this.getDeliveryDetails();
    this.productList = this.list;
    this.filterCategory = this.list;
    this.productList.forEach((a:any) => {

      Object.assign(a,{quantity:1,total:a.price});
    });
  }

  addtocart(item: any){
   // let id:any = this.deliveryId;
    this.cartService.addtoCart(item);
  }
  filter(category:string){
    this.filterCategory = this.productList
    .filter((a:any)=>{
      if(a.category == category || category==''){
        return a;
      }
    })
  }
  
  //   //method called OnInit
  getDeliveryDetails() {
    this._deliveryService.getDeliveryDetails().subscribe(
        //read data and assign to public variable projectProposal
        (data:any) => { this.delivery = data[data.length-1]},
          //this.deliveryId = data[data.length-1].id
       // console.log("delivery data -> ",data[data.length-1])
        
        err => console.error(err),
        () => console.log('finished loading')
    );
    //console.log("Delivery ->>", this.delivery);
  }
    onDelete(deliveryId: string) {
      this._deliveryService.deleteDeliveryDetails(deliveryId);
      this.router.navigate(['/listDeliveryDetails']);
    }
}
