import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-online-delivery',
  templateUrl: './online-delivery.component.html',
  styleUrls: ['./online-delivery.component.css']
})
export class OnlineDeliveryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
