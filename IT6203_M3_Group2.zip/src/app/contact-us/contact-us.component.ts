import { Component, OnInit } from '@angular/core';
import {default as contact} from './contactUs.json';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent implements OnInit {

  list: any ;
  constructor() { }

  ngOnInit(): void {
    this.list=contact;
  }

}
