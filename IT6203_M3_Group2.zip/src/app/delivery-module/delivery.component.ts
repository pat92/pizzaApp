import { Component, OnInit, Input, ViewChild  } from '@angular/core';
import { FormBuilder, Validators, FormArray  } from '@angular/forms';
import { DeliveryService } from '../services/delivery.service';
import {Router} from '@angular/router';
import {ActivatedRoute, ParamMap } from '@angular/router';
import { GeolocService } from '../services/geoloc.service';

declare var google: any;

@Component({
  selector: 'delivery-module',
  templateUrl: './delivery.component.html',
  styleUrls: ['./delivery.component.css']
})
export class DeliveryComponent implements OnInit {
@Input() zip: string = "";
@Input() flat: string = "";
@Input() street: string = "";
@Input() city: string = "";
@Input() state: string = "";
@Input() store: string = "";

  public pickUp:boolean = false;
  public online:boolean = true;
  public mode = 'Add'; //default mode
  private id: any; //project ID
  private delivery: any;
  //public buttonName:any = 'Show';
  // pickUp=true;
  // delivery=true;

  map: any;
  @ViewChild('map') mapElement: any;
  lat = 33.80287958747343;
  lng = -84.36624023259094;
  markers = [
    { lat: 33.89593100766195, lng: -84.46903213358196 },
    { lat: 33.818925041604736,  lng: -84.39178456153655 },
   { lat: 33.802455479771, lng: -84.36769463271375},
     { lat: 33.76911394010015, lng: -84.33367093483517},
     { lat: 33.76266337249914, lng: -84.38654345750616},
    { lat: 33.7749708142271, lang: -84.37914081520466}
  ];

  ngAfterViewInit(): void {
    const mapProperties = {
      center: new google.maps.LatLng(this.lat, this.lng),
      zoom: 11,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    this.map = new google.maps.Map(this.mapElement.nativeElement, mapProperties);

    this.markers.forEach(location => {
      var marker = new google.maps.Marker({
        position: new google.maps.LatLng(location.lat, location.lng),
        map: this.map
      });
    });
  }

  pickUpToggle() {
    this.pickUp = !this.pickUp;
    if(this.pickUp)  
      this.online = false;
  }

  deliveryToggle() {
    this.online = !this.online;
    if(this.online)  
      this.pickUp = false;
  }
  

  deliveryForm = this.fb.group({
    zip: ['', Validators.required,Validators.max(5),Validators.pattern('[0-9 ]*')],
      flat:['', Validators.required],
      street:['', Validators.required, Validators.pattern('[a-zA-Z ]*')],
      city: ['', Validators.required, Validators.pattern('[a-zA-Z ]*')],
      state:['', Validators.required, Validators.minLength(2),Validators.pattern('[a-zA-Z ]*')],
      store:['', Validators.required, Validators.pattern('[a-zA-Z ]*')]


  });

  get aliases() {
    return this.deliveryForm.get('aliases') as FormArray;
  }
  addAlias() {
    this.aliases.push(this.fb.control(''));
  }

  constructor(private fb: FormBuilder, private _deliveryService: DeliveryService, private _geoloction: GeolocService, private router:Router, public route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe((paramMap: ParamMap ) => {
      if (paramMap.has('_id'))
          { 
          this.mode = 'Edit'; /*request had a parameter _id */ 
          this.id = paramMap.get('_id');
           //request student info based on the id
           this._deliveryService.getDeliveryDetail(this.id).subscribe(
            data => { 
                //read data and assign to private variable student
                this.delivery = data;
                //populate the firstName and lastName on the page
                //notice that this is done through the two-way bindings
                this.zip = this.delivery.zip;
                this.flat = this.delivery.flat;
                this.street = this.delivery.street;
                this.city = this.delivery.city;
                this.state = this.delivery.state;
                this.store = this.delivery.store;                                
            },
            err => console.error(err),
            () => console.log('finished loading')
        );
    } 
      else {this.mode = 'Add';
          this.id = null; }
  });
  }

//   sendToAPIXU(city: string) {
//     console.log(this.city);
// }



  onSubmit() {
    // TODO: Use EventEmitter with form value
    console.log("You submitted: " + this.zip + " " + this.flat+ " " + this.street+ " " + this.city+" "+this.state+" "+this.store);
    if (this.mode == 'Add')
      this._deliveryService.addDeliveryDetails(this.zip,this.flat,this.street,this.city, this.state, this.store);
    if (this.mode == 'Edit')
      this._deliveryService.updateDeliveryDetails(this.id,this.zip,this.flat,this.street,this.city, this.state, this.store);
    this.router.navigate(['/listDeliveryDetails']);
  }


// zip: any = {
//   "Kennesaw": ["30144", "30152" ],
//   "Marietta":[ "30060", "30061", "30062", "30063", "30064", "30065", "30066", "30067", "30068", "30069" ],
//   "Woodstock":[ "30188", "30189" ]
// };

zip2: any = {
  "30144": ["Kennesaw", "Marietta" ],
  //"30060":[ "Cumming", "Roswell", "30062", "30063", "30064", "30065", "30066", "30067", "30068", "30069" ],
  "30060":[ "Cumming", "Roswell" ]
};



getCity = (theCurrentZip: any) => {
  return this.zip2[theCurrentZip];
}

onKeyUp(event: any){
    this.deliveryForm.patchValue({
      store: this.getCity(event.target.value)
    })
    this._geoloction.getLocation(this.getCity(event.target.value),this.state).subscribe(data => console.log(data));
  }
  // updateProfile() {
  //   this.profileForm.patchValue({
  //     firstName: 'Nancy',
  //     address: {
  //       street: '123 Drew Street'
  //     }
  //   });
  // }
  //zoom = 12

}
