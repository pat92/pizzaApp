import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class GeolocService {

  constructor(private http: HttpClient) { }

  getLocation(store: any, state: any){
    return this.http.get(
        'https://www.google.com/maps/search/?api=1&query=pizza+'+store+'+'+state
    );
}
}
