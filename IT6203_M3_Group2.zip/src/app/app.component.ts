import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { OMService } from './services/OM.service';
declare var google: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  title = 'My first AGM project';

  public totalItem : number = 0;
  public searchTerm !: string;
  constructor(private cartService : OMService) { }

  ngOnInit(): void {
    this.cartService.getProducts()
    .subscribe(res=>{
      this.totalItem = res.length;
    })

  }


  search(event:any){
    this.searchTerm = (event.target as HTMLInputElement).value;
    console.log(this.searchTerm);
    this.cartService.search.next(this.searchTerm);
  }


 
}

